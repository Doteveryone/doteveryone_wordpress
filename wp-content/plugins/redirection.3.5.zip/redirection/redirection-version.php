<?php

define( 'REDIRECTION_VERSION', '3.5' );
define( 'REDIRECTION_BUILD', 'd0709c001ac86f36f28aeed66d704238' );
define( 'REDIRECTION_MIN_WP', '4.5' );
