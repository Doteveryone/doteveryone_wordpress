<?php

namespace Aventura\Wprss\Core\Licensing\Api;

use Aventura\Wprss\Core\Licensing;

/**
 * When something goes wrong in the WPRSS Licensing API.
 * 
 * @since 4.8.1
 */
class Exception extends Licensing\Exception
{
}