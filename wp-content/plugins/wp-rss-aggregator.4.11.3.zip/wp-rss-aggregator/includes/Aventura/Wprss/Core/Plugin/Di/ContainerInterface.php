<?php

namespace Aventura\Wprss\Core\Plugin\Di;

use Interop\Container\ContainerInterface as BaseContainerInterface;

/**
 * Represents a generic WPRA container.
 *
 * @since 4.11
 */
interface ContainerInterface extends BaseContainerInterface
{
}
