<?php

namespace Aventura\Wprss\Core;

/**
 * Base class for all WPRA exceptions.
 * 
 * @since 4.8.1
 */
class Exception extends \Exception
{
}