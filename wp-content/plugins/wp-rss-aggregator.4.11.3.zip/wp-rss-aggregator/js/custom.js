jQuery( document ).ready( function() { 
if(jQuery.fn.colorbox) {
    jQuery( 'a.colorbox' ).colorbox(
    {iframe:true, width:'80%', height:'80%'}
    );
}
});